package week5_A4_FILES;


public class Student1 {

//	INITIALIZE VARIABLES
		private String name;
		private String grade;
		private double gpa;
		
//	SETTERS AND GETTERS
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getGrade() {
			return grade;
		}
		public void setGrade(String grade) {
			this.grade = grade;
		}
		public double getGpa() {
			return gpa;
		}
		public void setGpa(double gpa) {
			this.gpa = gpa;
		}

}
